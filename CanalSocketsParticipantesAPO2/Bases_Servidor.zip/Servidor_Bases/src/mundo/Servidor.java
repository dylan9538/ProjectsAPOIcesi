package mundo;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class Servidor {

	private ServerSocket server;
	private Socket canal;
	
	private ArrayList<String> participantes;

	public Servidor() {

		try {
			server = new ServerSocket(6666);
		} catch (IOException e) {
			e.printStackTrace();
		}
		participantes = new ArrayList<String>();
		
	}

	public String getCodigo(){
		String cadena = "";
		for (int i = 0; i < participantes.size(); i++) {
			if (participantes.get(i) != null){
				String participante = (String) participantes.get(i);
				cadena +=  (i+1) +"" + participante.charAt(0) + ",\n";
			}
		}
		return cadena;
	}

	public void RegistrarParticipante(String nombre)
			throws UnknownHostException, IOException {

			if (nombre != "" && nombre != null) {
			participantes.add(nombre);
				
			}
			canal.close();
		}

	
	public void eliminarParticipante(String nom)throws Exception{
		boolean encontro = false;
		if(nom!= null && !nom.equals("")){
			
			for (int i = 0; i < participantes.size() && !encontro; i++) {
				String participante = (String) participantes.get(i);
				if (participante.equals(nom)){
					participantes.remove(i);
					encontro = true;
				}
			}
			if(!encontro)
			throw new Exception("El participante no se ha registrado a�n");
		}
		else {
			throw new Exception("Ingrese un nombre v�lido");
		}
	}

	public ServerSocket getServer() {
		return server;
	}

	public void setServer(ServerSocket server) {
		this.server = server;
	}

	public Socket getCanal() {
		return canal;
	}

	public void setCanal(Socket canal) {
		this.canal = canal;
	}

    public ArrayList<String> getParticipantes() {
		return participantes;
	}

	public void setParticipantes(ArrayList<String> participantes) {
		this.participantes = participantes;
	}

	
}
